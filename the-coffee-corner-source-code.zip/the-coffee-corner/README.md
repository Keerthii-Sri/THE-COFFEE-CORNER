# ☕ The Coffee Corner

A modern, responsive café website concept featuring a welcome section, café story, filterable menu, signature specials, customer testimonials, opening hours, and contact information.

## Features
- Responsive desktop and mobile layout
- Menu category filters
- Add-to-cart interactions and live total calculation
- Contact form front-end validation and demo confirmation
- Café story, featured items, reviews, and opening hours
- Accessible labels and semantic page sections

## Built With
- HTML5
- CSS3
- Vanilla JavaScript
- Google Fonts
- Unsplash images

## Run Locally
1. Download or clone this repository.
2. Open `index.html` in a web browser.

No build tools or package installation are required.

## Customise
- Update café details, opening hours, and contact information in `index.html`.
- Edit menu products and prices in `script.js`.
- Change colours, spacing, and layout in `style.css`.
- Replace sample images with your own café photographs.

## Important Notes
This is a standalone front-end recreation inspired by the café project brief. It is not an export of the original Wix website source code. The cart is a browser-side demonstration only; no real orders or payments are processed. The contact form does not send messages until connected to a backend or form service. Replace sample reviews and placeholder contact details with accurate information before publishing.

## Live Wix Website
[Visit The Coffee Corner](https://kovvurikeerthii.wixsite.com/the-coffee-corner)

---
Made with ☕ and care.
