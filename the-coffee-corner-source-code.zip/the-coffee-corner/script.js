const products = [
  {id:1,name:"Cappuccino",category:"Hot Coffee",price:149,desc:"Rich espresso with silky steamed milk.",image:"https://images.unsplash.com/photo-1570968915860-54d5c301fa9f?auto=format&fit=crop&w=700&q=80"},
  {id:2,name:"Classic Espresso",category:"Hot Coffee",price:99,desc:"A bold little cup with a smooth finish.",image:"https://images.unsplash.com/photo-1510707577719-ae7c14805e3a?auto=format&fit=crop&w=700&q=80"},
  {id:3,name:"Caramel Latte",category:"Hot Coffee",price:179,desc:"Espresso, creamy milk and caramel sweetness.",image:"https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=700&q=80"},
  {id:4,name:"Iced Coffee",category:"Cold Coffee",price:169,desc:"Chilled coffee made for sunny afternoons.",image:"https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=700&q=80"},
  {id:5,name:"Mocha Frappe",category:"Cold Coffee",price:199,desc:"A cool blend of coffee and chocolate.",image:"https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=700&q=80"},
  {id:6,name:"Chocolate Brownie",category:"Desserts",price:129,desc:"A soft, chocolatey treat for your coffee break.",image:"https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=700&q=80"},
  {id:7,name:"Cheesecake Slice",category:"Desserts",price:199,desc:"Creamy, delicate and wonderfully indulgent.",image:"https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=700&q=80"},
  {id:8,name:"Grilled Sandwich",category:"Snacks",price:139,desc:"Toasted bread with a savoury, cheesy filling.",image:"https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=700&q=80"}
];
let cart = [];
const menuGrid = document.getElementById("menuGrid");
const cartDrawer = document.getElementById("cartDrawer");
const cartOverlay = document.getElementById("cartOverlay");

function renderMenu(category="All") {
  const shown = category === "All" ? products : products.filter(p => p.category === category);
  menuGrid.innerHTML = shown.map(p => `
    <article class="menu-card">
      <img src="${p.image}" alt="${p.name}" loading="lazy">
      <div class="menu-card-content">
        <h3>${p.name}</h3><p>${p.desc}</p>
        <div class="menu-card-bottom"><span class="price">₹${p.price}</span><button class="add-button" data-add="${p.id}">+ Add</button></div>
      </div>
    </article>`).join("");
}
function addToCart(id) {
  const item = cart.find(p => p.id === id);
  if (item) item.qty++; else cart.push({...products.find(p => p.id === id),qty:1});
  renderCart();
}
function renderCart() {
  const count = cart.reduce((sum,p) => sum+p.qty,0);
  const total = cart.reduce((sum,p) => sum+p.price*p.qty,0);
  document.getElementById("cartCount").textContent = count;
  document.getElementById("cartTotal").textContent = `₹${total}`;
  const container = document.getElementById("cartItems");
  container.innerHTML = cart.length ? cart.map(p => `
    <div class="cart-row"><div><strong>${p.name}</strong><br>₹${p.price} × ${p.qty}</div>
    <div><strong>₹${p.price*p.qty}</strong><br><button data-remove="${p.id}">Remove</button></div></div>`).join("") :
    '<p class="empty-cart">Your cart is waiting for something delicious.</p>';
}
function toggleCart(open) {
  cartDrawer.classList.toggle("open",open);
  cartOverlay.classList.toggle("show",open);
  cartDrawer.setAttribute("aria-hidden",String(!open));
}
document.getElementById("filters").addEventListener("click",e=>{
  const button=e.target.closest("[data-category]");
  if(!button)return;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===button));
  renderMenu(button.dataset.category);
});
menuGrid.addEventListener("click",e=>{
  const button=e.target.closest("[data-add]");
  if(button)addToCart(Number(button.dataset.add));
});
document.getElementById("cartItems").addEventListener("click",e=>{
  const button=e.target.closest("[data-remove]");
  if(button){cart=cart.filter(p=>p.id!==Number(button.dataset.remove));renderCart();}
});
document.getElementById("cartOpen").addEventListener("click",()=>toggleCart(true));
document.getElementById("cartClose").addEventListener("click",()=>toggleCart(false));
cartOverlay.addEventListener("click",()=>toggleCart(false));
document.getElementById("checkoutButton").addEventListener("click",()=>{
  alert(cart.length ? "This is a front-end demo. Connect an ordering backend before accepting real orders." : "Your cart is empty. Add an item first.");
});
document.getElementById("contactForm").addEventListener("submit",e=>{
  e.preventDefault();
  document.getElementById("formMessage").textContent="Thank you! This demo form is not connected to an email service yet.";
  e.target.reset();
});
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("mainNav").classList.toggle("open"));
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mainNav").classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();
renderMenu();
renderCart();
